Run the File - "link_prediction_using_community_labels_v6.py" with 'netscience.gml' 
dataset in the same directory as that of the code.

Only python3, networkx, sklearn and numpy are required for running the code. Prefer 
colab.research.google.com for running the program.