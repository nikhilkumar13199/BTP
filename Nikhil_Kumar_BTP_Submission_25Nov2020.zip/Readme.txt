1) .py file is just an alternative to .ipynb file in case it is needed.
2) Run the .ipynb file on Google Colaboratoy, after uploading datasets as is in the side bar.
3) For very large datasets, the program will run for about 40 mins on Google colaboratory (standard/free account).
4) For running .py file, please install networkx, scikit-learn, numpy and pass the correct path for dataset accordingly.